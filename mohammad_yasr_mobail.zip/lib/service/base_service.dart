import 'package:dio/dio.dart';

abstract class BaseService {
  Dio dio = Dio();
  String baseUrl = 'http://192.168.137.245:8000';
  late Response response;
}
