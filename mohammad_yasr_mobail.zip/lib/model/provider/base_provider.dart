import 'package:flutter/material.dart';

class BaseProvider extends ChangeNotifier{
  @override
  notifyListeners();
}